import { createContext } from "react";

const SessionContext = createContext(null);

export default SessionContext;